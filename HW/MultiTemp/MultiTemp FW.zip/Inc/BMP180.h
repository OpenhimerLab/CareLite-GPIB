#ifndef __BMPI2C_H
#define __BMPI2C_H

#include "stm32f0xx.h"
#include "stm32f0xx_hal_i2c.h"
#include "stm32f0xx_hal_rcc.h"

#define ADDR_BMP180		0xee

void test_pressure(void);

#endif 



#include "bmp180.h"
//#include "stdio.h"

short ac1;
short ac2; 
short ac3; 
unsigned short ac4;
unsigned short ac5;
unsigned short ac6;
short b1; 
short b2;
short mb;
short mc;
short md;
/* Private function prototypes -----------------------------------------------*/
void  Delay(uint32_t nCount);

extern uint8_t i2c_reg_write( uint8_t device_addr,uint8_t reg, uint8_t value );
extern uint8_t i2c_reg_read( uint8_t device_addr,uint8_t reg, uint8_t *value );
extern uint8_t i2c_reg_read_len( uint8_t device_addr,uint8_t reg, uint32_t *value ,uint8_t len);
extern void delay_ms(uint16_t nms);


int32_t  bmp180_presure=0,bmp180_temp=0;
float BMP180_temperature_float = 0,BMP180_presure_float = 0;


void temp_calibration(void)
{
  uint8_t buf[2];
  i2c_reg_read(ADDR_BMP180,0xaa,buf);
  ac1 = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xac,buf);
  ac2 = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xae,buf);
  ac3 = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xb0,buf);
  ac4 = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xb2,buf);
  ac5 = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xb4,buf);
  ac6 = buf[0] << 8 |buf[1]; 
  i2c_reg_read(ADDR_BMP180,0xb6,buf);
  b1 = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xb8,buf);
  b2 = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xba,buf);
  mb = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xbc,buf);
  mc = buf[0] << 8 |buf[1];
  i2c_reg_read(ADDR_BMP180,0xbe,buf);
  md = buf[0] << 8 |buf[1];
  //printf("ac1=%d,ac2=%d,ac3=%d,ac4=%d,ac5=%d,ac6=%d,b1=%d,b2=%d,mb=%d,mc=%d,md=%d\r\n",ac1,ac2,ac3,ac4,ac5,ac6,b1,b2,mb,mc,md);
}

void test_pressure(void)
{
  long x1,x2,x3,b3,b5,b6,b7,press_reg,pressure,temp_reg,temp;
  unsigned long b4;
  int i;

  uint32_t ReadBuffer[1];
  char oss = 0;  //���ֵ�ڶ���ѹʱ�����ý��Ĵ���
	 
	
  temp_calibration();
  //read uncompensated temperature
  i2c_reg_write(ADDR_BMP180,0xf4,0x2e);
  delay_ms(5);
  i2c_reg_read_len(ADDR_BMP180,0xf6,ReadBuffer,2);
  temp_reg = (long)(ReadBuffer[0]>>8);//ReadBuffer[0] << 8 | ReadBuffer[1];
  
  //calculate true temperature
  x1 = ((temp_reg - ac6) * ac5) >> 15;
  x2 = ((long) mc << 11) / (x1 + md);
  b5 = x1 + x2;
  temp = (b5 + 8) >> 4;
  bmp180_temp = temp;
	BMP180_temperature_float = bmp180_temp/10.0;
	printf ("2-�¶� : %.2f �� \r\n",BMP180_temperature_float);
  //read uncompensated pressure
  //////write 0x34+(oss<<6) into reg 0xF4, wait 4.5ms
  i2c_reg_write(ADDR_BMP180,0xf4,(0x34 +(oss<<6)));
  delay_ms(5);
  //read reg 0xF6 (MSB), 0xF7 (LSB), 0xF8 (XLSB)
  i2c_reg_read_len(ADDR_BMP180,0xf6,ReadBuffer,3);
  
  //////UP = (MSB<<16 + LSB<<8 + XLSB) >> (8-oss)
  press_reg = (long)(ReadBuffer[0]) >> (8 - oss);

  b6 = b5 - 4000;
  x1 = (b2 * ((b6 * b6) >> 12)) >> 11;
  x2 = (ac2 * b6) >> 11;
  x3 = x1 + x2;
  b3 = ((((long)ac1 * 4 + x3) << oss) + 2) / 4;  
  x1 = (ac3 * b6) >> 13;
  x2 = (b1 * ((b6 * b6)>> 12)) >> 16;
  x3 = ((x1 + x2 )+ 2) >> 2;
  b4 = (ac4 * (unsigned long)(x3 + 32768)) >> 15;
  b7 = ((unsigned long)press_reg - b3) * (50000 >> oss);
 
  
  if(b7 < 0x80000000)
  {
    pressure = (b7 * 2) / b4;
  }
  else
  {
    pressure = (b7 / b4) * 2;
  }
  //X1 = (p / 2^8 ) * (p / 2^8 )
  x1 = (pressure >> 8) * (pressure >> 8);
  //X1 = (X1 * 3038) / 2^16
  x1 = (x1 * 3038) >> 16;
  //X2 = (-7357 * p) / 2^16
  x2 = (-7357 * pressure) >> 16;
  //p = p + (X1 + X2 + 3791) / 2^4
  pressure = pressure + ((x1 + x2 + 3791) >> 4);

  bmp180_presure  = pressure;
  bmp180_presure  /= 10;
	BMP180_presure_float = bmp180_presure/1.0;
  printf("2-��ѹ : %d\r\n",bmp180_presure);
}



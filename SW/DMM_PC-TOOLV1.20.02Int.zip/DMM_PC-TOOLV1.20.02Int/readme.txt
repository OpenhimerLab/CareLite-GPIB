[The DMM PC-TOOL International version-Readme]
Terms:
The Copyright of this software is own by ZDD. It is free for personal users, while for commercial purposes, authorization is required.
The software may or may not consist of bug, the author is not responsible of all consequences related to the software.
English translation is done by YJW, National Taiwan University, 2020.

本軟體的所有版權歸作者 ZDD 所有，個人用戶可以免費使用，如用於商業目的，請聯繫作者獲得授權，謝謝。
本軟體免費提供給群友使用，但本軟體可能存在BUG，使用過程中由本軟體造成的一切後果由使用者自己承擔，作者不承擔任何責任。
英文翻譯: NTU Erikovsky 2020/2

本軟體主要用於 34401A 6.5位數字萬用表或 SCPI 命令相容的其它品牌的萬用表。
本軟體支援串列埠直接連線或通過 MeterCare 的 GPIB 連線 34401A。通過串列埠直接連線時，MeterCare 僅作為溫度感測器使用。

[Simple User's Guide]
In late 2019, DMM PC-TOOL was developed by ZDD for data logging, mathematic computing and statistical analyzing. DMM PC-TOOL was firstly and mainly compatible with
HP 34401A, the most common and popular DMM all over the world. Later, with further efforts the DMM PC-TOOL is surpporting more DMM types, and providing wider functionality
such as remote calibration and temperature-related calculation.

The MeterCare is a open-source hardware, which is actually an GPIB-USB interface with integrated temperature sensor ports.Initially, the DMM PC-TOOL is intented 
and developed to cooperate with Metercare. Nevertheless, the DMM PC-TOOL could perform its function without MeterCare. It is compatible with other GPIB-USB
interface, serial-USB converter, and stand-alone temperature sensors.

As the DMM PC-TOOL is developed by LabView 2017;in order to run PC-TOOL properly, it is necessary to install the LabView Run-Time Engine and NI-VISA drivers.
 
一、注意事項：
1、如果沒有桃卡（MeterCare），也沒有其它的溫度感測器，一定要在「選項」里，設溫度感測器個數為「無或不需要溫度」。
2、MeterCare 的超時設定，在「選項」選項卡下設定。必須大於表的當前最大響應時間，100PLC時建議5000ms。
3、34401A的RS232線纜的接線方式（至少保證5線）：2-3，3-2，4-6，6-4，5-5。且必須保證電腦端的RS232具有DTR/DSR流控功能。
4、操作時，千萬不要點選太快，至少要保證上一次的操作成功結束后，才能繼續下一個操作。特別是在100PLC時，反應時間大約4s。
5、由於本軟體是用 LabVIEW 2017 版本開發，故需要在安裝 LabVIEW 2017 及以上版本（或者 LabVIEW 的 Run-Time Engine）的 PC 上才能執行。
   同時還要安裝串列埠所需要的NI-VISA驅動。最簡單的辦法就是從群檔案里下載「LabVIEW 2017執行引擎安裝包」安裝一次，然後就可以直接下載
   使用由LabVIEW 2017開發的各種上位機的免安裝版本。

二、功能簡介：
1、面板按鍵的功能，除明確標出以外，方向鍵的功能定義如下：
   上：量程增大；下：量程減小
   左：NPLC減小；右：NPLC增大

2、當選擇7.5位及以上模式且顯示屏開啟時，通過「選項」界面里的「回顯開關」，決定是否將7.5位及以上格式數據回顯到顯示屏。

3、「DMM面板」的「啟動波形接收」按鈕不影響數據採集，點亮時才將接收到的數據存入波形里。
   「儲存接收數據」按鈕，可以將接收到的數據記錄以.csv檔案格式，儲存到data子目錄下，檔名以「年月日 時-分-秒」命名。
   儲存的數據格式如下：
			日期時間,							溫度1(℃),	溫度2(℃),	Voltage (VDC)
			2019-06-08 20:11:57,	30.18,			44.37,			+7.06909230E+00

4、「實時波形」選項卡的主要功能是數據採集和溫度特性分析。可以設定丟棄異常數據，也可以隨時刪除異常數據，還可以選擇任意時間段的數據進行顯示和分析。
   波形數據也可以通過右鍵，導出到Excel。「暫停波形」只是暫停顯示，採集繼續，波形數據不會丟失。
   特別功能：通過調整實時波形右下角的滾動條，可以調節主測量數據和溫度數據的相對位置，來減少由於溫度的超前或滯後導致的升溫和降溫過程的數據不一致性。
   儘量使得升溫和降溫過程的曲線重合，使溫度特性曲線更準確。

5、「示波器」選項卡的主要功能是配合噪聲放大器，測量0.1-10Hz的低頻噪聲。關閉顯示屏可以提高採樣速度50%左右(大約從40SPS提高到60SPS)。

6、「數據終端」選項卡主要是除錯用，通過MeterCare連線時，請不要使用發送功能，會出錯的。

7、當使用 MX+B 功能時，自動切換到 DCV 100mV 檔。此檔的 M、B 和單位可以在「選項」界面里設定。
   很多其它參數設定，也在「選項」界面里進行。這裡設定的參數，除溫漂參數外，在軟體退出時會自動儲存到 setting.ini 檔案里。

8、表的溫度補償參數儲存在 tc.ini 檔案里，可根據說明自行修改。目前只支援 DCV、DCI 和 OHM 4W 的各量程的溫度補償。

9、「校準」選項卡的功能就不用說了。

10、如有不明白的，可以點選右鍵，選擇「說明和提示」檢視有關說明。

如果需要多視窗啟動，在應用程式的ini檔案里加上下面一行即可。
	 allowmultipleinstances = TRUE

預設
量程

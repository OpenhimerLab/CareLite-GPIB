#!/bin/bash

sudo openocd -f ../tcl/target/stm32f0x_cmsisdap.cfg

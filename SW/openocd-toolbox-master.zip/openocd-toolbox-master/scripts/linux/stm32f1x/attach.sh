#!/bin/bash

sudo openocd -f ../tcl/target/stm32f1x_cmsisdap.cfg

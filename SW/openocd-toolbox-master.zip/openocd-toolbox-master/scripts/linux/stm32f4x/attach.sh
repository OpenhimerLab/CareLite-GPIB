#!/bin/bash

sudo openocd -f ../tcl/target/stm32f4x_cmsisdap.cfg
